La practica consta de 3 proyectos:

	-GugleCar_aStar_puro: Es el principal, soluciona todos los mapas con el A* tardando mucho. Contiene los comentarios con todos los @author bien puestos.  -> Mirar documentacion en este.
	-GugleCar_pulgarcito: Es el que ejecuta pulgarcito, puede tener el @author desactualizado ya que se hizo antes que los otros.
	-GugleCar_aStar_eficiente : Es identico al puro pero el A* no es el m�s eficiente, util para el mapa 10.

Para cambiar el mapa de ejecuci�n modificar la variable MAPA en la clase AgentCar.
Para cambiar el numero de pasos del pulgarcito cambiar la variable MAX_STEPS en AgentExplorer